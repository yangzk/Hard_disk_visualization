library('FactoMineR')
install.packages('missMDA')
require(missMDA)

setwd('/Users/zhenkai-Yang/Dropbox/2015\ DataVis/Hard_disk/data')
out_fail <- read.csv(file="out_fail.csv",header=TRUE)
names(out_fail)
dim(out_fail)
hist(out_fail[,7])

normalized <- subset(out_fail,select=names(out_fail)[seq(from=6,by=2,to=84)])
raw <- subset(out_fail,select=names(out_fail)[seq(from=6,by=2,to=84)+1])
names(raw)
summary(raw)

log_raw <- logb(raw+1)
log_raw <- subset(log_raw,select=c("smart_5_raw","smart_187_raw",
                                   "smart_188_raw", "smart_197_raw","smart_198_raw"))

summary(log_raw)
PCA_raw <- PCA(log_raw,scale.unit = TRUE,ncp = 10)

summary(PCA_raw)
names(PCA_raw)
names(PCA_raw$ind$coord)
summary(PCA_raw$ind$coord)
hist(PCA_raw$ind$coord[,5])

names(out_fail)
PCA_raw_out <- cbind(out_fail[,1:5],PCA_raw$ind$coord)
write.csv(PCA_raw_out,file="PCA_raw_out.csv",quote=F)
